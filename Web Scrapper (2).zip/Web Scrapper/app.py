from flask import Flask, render_template, request
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from time import sleep

app = Flask(__name__)

products = []

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        smartphone_name = request.form['smartphone_name']
        num_pages_to_scrape = 1 

        chrome_options = Options()
        chrome_options.add_argument("--headless")  

        #User Agent id below replace it accordingly !!!!
        chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36") 
        

        # Orignal scipt
        driver = webdriver.Chrome(options=chrome_options)
        driver.get("https://www.amazon.com/s?k={}".format(smartphone_name))

        for page in range(num_pages_to_scrape):
            print("Scraping page", page + 1)
            # product_elements = driver.find_elements(By.XPATH, "//span[@class='a-size-medium a-color-base a-text-normal']")
            product_elements = driver.find_elements(By.XPATH, "//span[@class='a-size-base-plus a-color-base a-text-normal']") #ae products
 
            for product_element in product_elements:
                products.append(product_element.text)

            try:
                next_button = driver.find_element(By.XPATH, "//a[contains(@class, 's-pagination-next')]")
                next_button.click()
            except:
                print("No 'Next' button found.")
                break

            sleep(8)

        driver.quit()

        return render_template('results.html', products=products)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
    